import { Injectable } from '@angular/core';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private products : Product[] = [
    { id : 113, name : "priya", cost : 89636.656},
    { id : 114, name : "riya", cost : 56912.41 }
    
     
    
  ];

  constructor() { }

  addProduct(product : Product) {
    this.products.push(product);
    return true;
  }
}
