import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

  product : Product = {"id" : 0, "name" : '', "cost" : 0}  


  constructor(private productService : ProductService) { }

  ngOnInit() {
  }

  add() {
    console.log(this.product.id + " " + this.product.name + " " + this.product.cost + " ");

    this.productService.addProduct(this.product);
    this.product = {"id" : 0, "name" : '', "cost" : 0} 
  }

}
