let mobileArray1:any=[11,"oppo", 45789.56];
let mobileArray2:any=[12,"vivo", 20000];
let mobileArray3:any=[13,"apple", 102369];

class Mobile {
    mobileId : number;
    mobileName : string;
    mobileCost : number;

    constructor(id:number, name: string, cost: number) {
        this.mobileId = id;
        this.mobileName = name;
        this.mobileCost = cost;
    }

    printMobileDetails() {
        console.log(mobileArray1);
        console.log(mobileArray2);
        console.log(mobileArray3);
    }
}