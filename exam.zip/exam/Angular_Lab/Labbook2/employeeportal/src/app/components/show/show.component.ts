import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/bean/employee';
import { EmployeeService } from 'src/app/service/employee.service';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {

  employees : Employee[];

  constructor(private employeeService : EmployeeService) { }

  ngOnInit() {
    this.employees = this.employeeService.getAllEmployees();
  }

  delete(i : number) {

    if(confirm("confirm delete?")) {
      this.employeeService.deleteEmployee(i);
      console.log(i + "deleted");
    }
  }

}
