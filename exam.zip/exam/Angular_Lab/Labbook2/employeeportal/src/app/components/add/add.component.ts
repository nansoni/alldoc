import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/bean/employee';
import { EmployeeService } from 'src/app/service/employee.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  emp : Employee = {"id" : 0, "name" : '', "salary" : 0, "department" : ''}

  constructor(private employeeService : EmployeeService) { }

  ngOnInit() {
  }

  add() {
    alert(this.emp.id + " " + this.emp.name + " " + this.emp.salary + " "
      +this.emp.department);

    this.employeeService.addEmployee(this.emp);
    this.emp = {"id" : 0, "name" : '', "salary" : 0, "department" : ''} 
  }

}
