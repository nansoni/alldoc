import { Injectable } from '@angular/core';
import { Employee } from '../bean/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private employees : Employee[] = [
    { id : 113, name : "priya", salary : 89636.656, department : "female" },
    { id : 114, name : "riya", salary : 56912.41, department : "female" },
    { id : 105, name : "shriya", salary : 142369.12, department : "female" },
    { id : 123, name : "tom", salary : 78541.96, department : "male" },
    { id : 133, name : "jerry", salary : 23694.00, department : "male" }
        
  ];

  constructor() { }

  getAllEmployees() : Employee[] {
    return this.employees;
  }

  addEmployee(employee : Employee) {
    this.employees.push(employee);
    return true;
  }

  deleteEmployee(i : number) {
    this.employees.splice(i,1);
  }
}
