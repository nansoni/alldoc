import { Injectable } from '@angular/core';
import { Employee } from '../bean/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private employees : Employee[] = [
    { id : 1001, name : "Rahul", salary : 9000, department : "JAVA", joiningDate : "6/12/2014" },
    { id : 1002, name : "Vikas", salary : 11000, department : "ORAAPS", joiningDate : "6/12/2017" },
    { id : 1003, name : "Uma", salary : 12000, department : "JAVA", joiningDate : "6/12/2010" },
    { id : 1004, name : "Sachin", salary : 11500, department : "ORAAPS", joiningDate : "11/12/2017" },
    { id : 1005, name : "Amol", salary : 7000, department : ".NET", joiningDate : "1/1/2018" }
        
  ];

  constructor() { }

  getAllEmployees() : Employee[] {
    return this.employees;
  }

  addEmployee(employee : Employee) {
    this.employees.push(employee);
    return true;
  }

  deleteEmployee(i : number) {
    this.employees.splice(i,1);
  }

}
