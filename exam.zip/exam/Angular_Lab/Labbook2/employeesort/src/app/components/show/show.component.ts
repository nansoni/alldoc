import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/bean/employee';
import { EmployeeService } from 'src/app/service/employee.service';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {

  employees : Employee[];

  constructor(private employeeService : EmployeeService) { }

  ngOnInit() {
    this.employees = this.employeeService.getAllEmployees();
  }

  delete(i : number) {

    if(confirm("confirm delete?")) {
      this.employeeService.deleteEmployee(i);
      console.log(i + "deleted");
    }
  }

  sortEmpById(employees : Employee[]) {
    return employees.sort((a, b) => a['id'] > b['id'] ? 1 : a['id'] === b['id'] ? 0 : -1);
  }

  sortEmpByName(employees : Employee[]) {
    return employees.sort((a, b) => a['name'] > b['name'] ? 1 : a['name'] === b['name'] ? 0 : -1);
  }

  sortEmpBySalary(employees : Employee[]) {
    return employees.sort((a, b) => a['salary'] > b['salary'] ? 1 : a['salary'] === b['salary'] ? 0 : -1);
  }

  sortEmpByDept(employees : Employee[]) {
    return employees.sort((a, b) => a['department'] > b['department'] ? 1 : a['department'] === b['department'] ? 0 : -1);
  }

  sortEmpByDate(employees : Employee[]) {
    return employees.sort((a, b) => <any> new Date('a.joiningDate') - <any> new Date('b.joiningDate') ? 1 : <any> new Date('a.joiningDate') === <any> new Date('b.joiningDate') ? 0 : -1);
  }

}

