import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ShowEmployeesComponent } from './show-employees/show-employees.component';
import { UpdateComponent } from './update/update.component';
import { HeaderComponent } from './header/header.component';
import { UpdateService } from './update.service';

@NgModule({
  declarations: [
    AppComponent,
    ShowEmployeesComponent,
    UpdateComponent,
    HeaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [UpdateService],
  bootstrap: [AppComponent]
})
export class AppModule { }
