import { Component, OnInit } from '@angular/core';
import data from '../../data/array.json'
import { UpdateService } from '../update.service';
@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  array=data
  emp:any
  emId:any
  emName:any
  emSal:any
  emDep:any
  index=null;
  constructor(private service: UpdateService) { }
  
  ngOnInit() {
    if (this.service.subsVar==undefined) {    
      this.service.subsVar = this.service.    
      invokeupdate.subscribe((i:number) => {    
        this.view(i);    
      });}
  }
  view(i:number)
  {
    this.emId=this.array[i].empId
    this.emName=this.array[i].empName
    this.emSal=this.array[i].empSal
    this.emDep=this.array[i].empDep
    this.index=i
  }
  setnew(form)
  {
      this.array.splice(this.index,1,{
        empId:this.emId,
        empName:this.emName,
        empSal:this.emSal,
        empDep:this.emDep
    })

  }
}
