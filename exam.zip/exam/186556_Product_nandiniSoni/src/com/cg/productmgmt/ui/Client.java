package com.cg.productmgmt.ui;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

import com.cg.productmgmt.bean.Product;
import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductService;
/**
 * asking the user to choose from the given options
 * @author nansoni
 *applying validations
 */
public class Client {
	public static void main(String[] args) throws ProductException {

		String continueChoice;
		boolean continueValue = false;
		Scanner scanner = null;
		do {
			System.out.println("** Welcome to Product hike updation Application**");
			System.out.println("Select Option from the below Menu");
			System.out.println("1) Update Product Price");
			System.out.println("2) Display Product Details");
			System.out.println("3) Exit");

			IProductService service = new ProductService();

			int choice = 0;
			boolean choiceFlag = false;
			do {

				scanner = new Scanner(System.in);
				System.out.println("Enter input:");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;

					boolean nameFlag = false;

					String productCategory = "";

					String name = "";
					switch (choice) {

					case 1:
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter name:");
							name = scanner.nextLine();
							try {
								service.validateCategoryName(name);
								nameFlag = true;
							} catch (ProductException e) {
								nameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!nameFlag);
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Category:");
							productCategory = scanner.nextLine();
							try {
								service.validateCategoryName(productCategory);
								nameFlag = true;
							} catch (ProductException e) {
								nameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!nameFlag);

						int hike = 0;
						boolean hikeFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter price hike:");
							try {
								hike = scanner.nextInt();
								service.validatehike(hike);
								hikeFlag = true;
							} catch (InputMismatchException e) {
								hikeFlag = false;
								System.err.println("Cost should be in digits");
							} catch (ProductException e) {
								hikeFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!hikeFlag);

						System.out.println("hike added");
						Map<String, String> feedbackMap = new HashMap<String, String>();

						/*
						 * Product product=new Product(name,productCategory,hike);
						 * map=service.addCategoryDetails(productCategory,hike);System.out.println(map);
						 */
						break;

					case 2:

						Map<String, Integer> feedbackMap1 = service.getProductDetails();
						System.out.println(feedbackMap1);

						break;

					case 3:
						System.out.println("Thank u, visit again");
						System.exit(0);
						break;
					default:
						System.out.println("input should be 1,2 or 3");
						choiceFlag = false;
						break;
					}

				} catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}

			} while (!choiceFlag);

			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);

		} while (continueValue);

	}
}