package com.cg.productmgmt.service;

import java.util.Map;

import com.cg.productmgmt.exception.ProductException;

public interface IProductService {

	public boolean validateCategoryName(String vehicleName) throws ProductException;

	public boolean validatehike(int vehicleCost) throws ProductException;

	public int updateProducts(String Category, int hike) throws ProductException;

	public Map<String, Integer> getProductDetails() throws ProductException;

	public Map<String, Integer> getFeedbackReport();

	public Object addCategoryDetails(String productCategory, int hike);
}
