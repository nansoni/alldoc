package com.cg.productmgmt.service;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

import com.cg.productmgmt.bean.Product;
import com.cg.productmgmt.dao.IProductDAO;
import com.cg.productmgmt.dao.ProductDAO;

public class Test {

	static IProductDAO dao=null;
	Product product;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		dao=new ProductDAO();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		dao=null;
	}

	@Before
	public void setUp() throws Exception {
		//product=new Product("lux","100","soap");
	}

	@After
	public void tearDown() throws Exception {
	}

	@org.junit.Test
	public void test() {
		fail("Not yet implemented");
	}

}
