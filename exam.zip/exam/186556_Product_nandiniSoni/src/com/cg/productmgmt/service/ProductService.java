package com.cg.productmgmt.service;

import java.util.Map;
import java.util.regex.Pattern;


import com.cg.productmgmt.dao.IProductDAO;
import com.cg.productmgmt.dao.ProductDAO;
import com.cg.productmgmt.exception.ProductException;

public class ProductService implements IProductService {
	IProductDAO productDao=new ProductDAO();
	@Override
	public int updateProducts(String productCategory, int hike) throws ProductException {
		return hike;
		
		
	}

	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		
		return productDao.getProductDetails();
	}
/**
 * applying validations for category name
 */
	@Override
	public boolean validateCategoryName(String Categoryname) throws ProductException {
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{3,}";

		if (!Pattern.matches(nameRegEx, Categoryname)) {
			throw new ProductException("first letter should be capital ");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}

	@Override
	/**
	 * applying validations for hike
	 */
	public boolean validatehike(int hike) throws ProductException {
		boolean costFlag = false;

		if (hike < 0 ) {
			throw new ProductException("hike cannot be less than 0");
		} else {
			costFlag = true;
		}
		return costFlag;

	}
	
	

	@Override
	public Object addCategoryDetails(String productCategory, int hike) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Integer> getFeedbackReport() {
		// TODO Auto-generated method stub
		return null;
	}

}
