package com.cg.productmgmt.dao;

import java.util.Map;

import com.cg.productmgmt.exception.ProductException;
/**
 * 
 * @author nansoni
 *
 */
public interface IProductDAO {
/**
 * 
 * @param Category
 * @param hike
 * @return
 * @throws ProductException
 * methods for products 
 * map declaration
 */
	public int updateProducts(String Category, int hike) throws ProductException;

	public Map<String, Integer> getProductDetails() throws ProductException;

	Map<String, Integer> updateProducts(String Category, Integer hike) throws ProductException;

	public int addFeedbackDetails(String productCategory, int hike);
}
