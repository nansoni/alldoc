package com.cg.productmgmt.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.cg.productmgmt.exception.ProductException;

public class ProductDAO implements IProductDAO {
	static Map<String, Integer> feedbackMap = new HashMap<String, Integer>();

	// for product name as key and category as value
	static Map<String, String> productDetails;
	// map for product name as key and price as value
	static Map<String, Integer> salesDetails;
	static HashMap<String, Integer> output = new HashMap<>();
/**
 * the database containing values and maps
 */
	static {
		productDetails = new HashMap<>();
		productDetails.put("lux", "soap");
		productDetails.put("colgate", "paste");
		productDetails.put("pears", "soap");
		productDetails.put("sony", "electronics");
		productDetails.put("samsung", "electronics");
		productDetails.put("facepack", "cosmatics");
		productDetails.put("facecream", "cosmatics");

		salesDetails = new HashMap<>();
		salesDetails.put("lux", 100);
		salesDetails.put("colgate", 50);
		salesDetails.put("pears", 70);
		salesDetails.put("sony", 10000);
		salesDetails.put("samsung", 23000);
		salesDetails.put("facepack", 100);
		salesDetails.put("facecream", 60);

		

		Iterator<String> iterator1 = productDetails.keySet().iterator();

		

			Iterator<String> iterator2 = salesDetails.keySet().iterator();
			for (Map.Entry<String, String> entry : productDetails.entrySet()) {
				System.out.println(entry.getKey()+salesDetails.get(entry.getKey()));
			}
		/*	while (iterator2.hasNext()) {

				String product1 = iterator2.next();
				int price = 0;
				price = salesDetails.get(price);

				if (product1.equals(price)) {

					output.put(product1, price);

				}

			}

		}*/

		System.out.println(output);

	}

	@Override
	public int updateProducts(String Category, int hike) throws ProductException {
		for (Map.Entry<String, String> entry : productDetails.entrySet()) {
			int price = salesDetails.get(entry.getKey());
			price = price + hike;
			salesDetails.put(entry.getKey(), price);
		}
		return hike;

	}

	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		// TODO Auto-generated method stub
		return salesDetails;
	}

	@Override
	public Map<String, Integer> updateProducts(String Category, Integer hike) throws ProductException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int addFeedbackDetails(String productCategory, int hike) {
		// TODO Auto-generated method stub
		return 0;
	}

	public static Map<String, Integer> getSalesDetails() {
		return salesDetails;
	}

	public static void setSalesDetails(Map<String, Integer> salesDetails) {
		ProductDAO.salesDetails = salesDetails;
	}

}
