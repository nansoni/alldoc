package com.cg.stepDef;
/*
 * @author nansoni
 */
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
/*
 * runner class
 */
@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty" },features = {"C:\\BDD556\\RegistrationForm\\src\\test\\java\\com\\cg\\feature\\Registration.feature"})
public class RegistrationRunner {

}
