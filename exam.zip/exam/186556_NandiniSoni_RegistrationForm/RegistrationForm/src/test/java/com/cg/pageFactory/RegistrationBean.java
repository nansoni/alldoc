package com.cg.pageFactory;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
/*
 * @author nansoni
 */

public class RegistrationBean {
/*
 * declaring webdriver
 */
	WebDriver driver;
	/*
	 * declaring all the variables 
	 */
	@FindBy(how = How.NAME, using = "userid")
	@CacheLookup
	WebElement userid;
	
	@FindBy(how = How.NAME, using = "passid")
	@CacheLookup
	WebElement passid;
	
	@FindBy(how = How.NAME, using = "username")
	@CacheLookup
	WebElement username;
	
	@FindBy(how = How.NAME, using = "address")
	@CacheLookup
	WebElement address;
	
	@FindBy(how = How.NAME, using = "country")
	@CacheLookup
	WebElement country;
	
	@FindBy(how = How.NAME, using = "zip")
	@CacheLookup
	WebElement zip;
	
	@FindBy(how = How.NAME, using = "email")
	@CacheLookup
	WebElement email;
	
	@FindBy(how = How.NAME, name = "gender")
	private List<WebElement> gender;
	///html/body/form/ul/li[18]/label
	@FindBy(xpath = "/html/body/form/ul/li[18]/label")
	@CacheLookup
	WebElement language;
	
	@FindBy(how = How.NAME, using = "desc")
	@CacheLookup
	WebElement desc;
	
	@FindBy(how = How.NAME, using = "submit")
	@CacheLookup
	WebElement submit;
/*
 * generating getters and setters
 */
	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid.sendKeys(userid);
	}

	public WebElement getPassid() {
		return passid;
	}

	public void setPassid(String passid) {
		this.passid.sendKeys(passid);
	}

	public WebElement getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country.sendKeys(country);
	}

	public WebElement getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip.sendKeys(zip);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}



	public String getGender() {

		for (WebElement element : gender) {
			if (element.isSelected()) {
				return element.getAttribute("value");
			}
		}
		return null;
	}

	public void setGender(String gender) {
		if (gender.equals("Male"))
			this.gender.get(0).click();
		else
			this.gender.get(1).click();
	}

	public WebElement getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language.sendKeys(language);
	}

	public WebElement getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc.sendKeys(desc);
	}

	public WebElement getSubmit() {
		return submit;
	}

	public void setSubmit() {
		this.submit.click();
	}	
	/*
	 * constructor for driver
	 */
	public RegistrationBean(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
}
