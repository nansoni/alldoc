package com.cg.stepDef;
/*
 * @author nansoni
 */
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.pageFactory.RegistrationBean;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
/*
 * My step definition class
 */
public class RegistrationStepDef {
/*
 * declaring drivers and bean
 */
	private WebDriver driver;
	private RegistrationBean bean;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\BDD556\\RegistrationForm\\Repositiory\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	
	
	@Given("^User is on Registration Form page$")
	public void user_is_on_Registration_Form_page() throws Throwable {
		driver.get("C:\\BDD556\\RegistrationForm\\Repositiory\\RegistrationForm.html");
		bean = new RegistrationBean(driver);
		
	   
	}

	@Then("^check the title of page is 'Welcome to JobsWorld'$")
	public void check_the_title_of_page_is_Welcome_to_JobsWorld() throws Throwable {
		String expectedMessage = "Welcome to JobsWorld";
		String actualMessage = driver.getTitle();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}

	@Given("^user is on 'Registration Form' page$")
	public void user_is_on_Registration_Form_page1() throws Throwable {
		driver.get("C:\\BDD556\\RegistrationForm\\Repositiory\\RegistrationForm.html");
		bean = new RegistrationBean(driver);
		
	   
	}

	@When("^user enters invalid user Id$")
	public void user_enters_invalid_user_Id() throws Throwable {
		bean.setUserid("");
		bean.setSubmit();
		
	
	}

	@Then("^display 'User Id should not be empty/length be between (\\d+) to (\\d+)'$")
	public void display_User_Id_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
		
		  String expectedMessage =
		  "User Id should not be empty / length be between 5 to 12";
		  String actualMessage= driver.switchTo().alert().getText(); 
		  Assert.assertEquals(expectedMessage,actualMessage);
		  driver.switchTo().alert().accept();
		  driver.close();
		 
		
		
		
	}

	@When("^user enters invalid password$")
	public void user_enters_invalid_password() throws Throwable {
		bean.setUserid("123456");
		bean.setPassid("");
		bean.setSubmit();
	   
	}

	@Then("^display 'Password should not be empty/length be between (\\d+) to (\\d+)'$")
	public void display_Password_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
		String expectedMessage = "Password should not be empty / length be between 7 to 12";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid name$")
	public void user_enters_invalid_name() throws Throwable {
		bean.setUserid("123456");
		bean.setPassid("nandinii");
		bean.setUsername("");
		bean.setSubmit();
	  
	}

	@Then("^display 'Name should not be empty and must have alphabet characters only'$")
	public void display_Name_should_not_be_empty_and_must_have_alphabet_characters_only() throws Throwable {
		String expectedMessage = "Name should not be empty and must have alphabet characters only";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	  
	}

	@When("^user enters invalid address$")
	public void user_enters_invalid_address() throws Throwable {
		bean.setUserid("123456");
		bean.setPassid("nandinii");
		bean.setUsername("nandini");
		bean.setAddress("");
		bean.setSubmit();
	   
	}

	@Then("^display 'User address must have alphanumeric characters only'$")
	public void display_User_address_must_have_alphanumeric_characters_only() throws Throwable {
		String expectedMessage = "User address must have alphanumeric characters only";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	   
	}
	@When("^user enters invalid country$")
	public void user_enters_invalid_country() throws Throwable {
		bean.setUserid("123456");
		bean.setPassid("nandinii");
		bean.setUsername("nandini");
		bean.setAddress("abcdef");
		bean.setCountry("");
		bean.setSubmit();
	}

	@Then("^display 'Select your country from the list'$")
	public void display_Select_your_country_from_the_list() throws Throwable {
		String expectedMessage = "Select your country from the list";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}


	@When("^user enters invalid zipcode$")
	public void user_enters_invalid_zipcode() throws Throwable {
		bean.setUserid("123456");
		bean.setPassid("nandinii");
		bean.setUsername("nandini");
		bean.setAddress("abcdefg");
		bean.setCountry("India");
		bean.setZip("");
		bean.setSubmit();
	 
	}

	@Then("^display 'ZIP Code must have numeric characters only'$")
	public void display_ZIP_Code_must_have_numeric_characters_only() throws Throwable {
		String expectedMessage = "ZIP code must have numeric characters only";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid email Id$")
	public void user_enters_invalid_email_Id() throws Throwable {
		bean.setUserid("123456");
		bean.setPassid("nandinii");
		bean.setUsername("nandini");
		bean.setAddress("abcdefg");
		bean.setCountry("India");
		bean.setZip("462021");
		bean.setSubmit();
		
	  
	}

	@Then("^display 'You have entered an invalid email address'$")
	public void display_You_have_entered_an_invalid_email_address() throws Throwable {
		String expectedMessage = "You have entered an invalid email address!";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user selects nothing$")
	public void user_selects_nothing() throws Throwable {
		bean.setUserid("123456");
		bean.setPassid("nandinii");
		bean.setUsername("nandini");
		bean.setAddress("abcdefg");
		bean.setCountry("India");
		bean.setZip("462021");
		bean.setEmail("nandinisoni@capgemini.com");
		bean.setSubmit();
	  
	}

	@Then("^display 'Please Select gender'$")
	public void display_Please_Select_gender() throws Throwable {
		String expectedMessage = "Please Select gender";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	  
	}
	
	/*
	 * @When("^user selects language$") public void user_selects_language() throws
	 * Throwable { bean.setUserid("123456"); bean.setPassid("nandinii");
	 * bean.setUsername("nandini"); bean.setAddress("abcdefg");
	 * bean.setCountry("India"); bean.setZip("462021");
	 * bean.setEmail("nandinisoni@capgemini.com"); bean.setGender("Female");
	 * bean.setLanguage("English"); bean.setSubmit(); }
	 * 
	 * @Then("^display Then 'You are Succesfully registered your vehicle'alert message should be displayed$"
	 * ) public void
	 * display_Then_You_are_Succesfully_registered_your_vehicle_alert_message_should_be_displayed
	 * () throws Throwable { String expectedMessage =
	 * "Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile"
	 * ; String actualMessage = driver.switchTo().alert().getText();
	 * Assert.assertEquals(expectedMessage, actualMessage);
	 * driver.switchTo().alert().accept(); driver.close(); }
	 */
/*
 * code ends here
 */
}
