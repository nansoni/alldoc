package com.capgemini.presentation;

import java.util.Scanner;

import com.capgemini.bean.Employee;
import com.capgemini.service.EmployeeService;
import com.capgemini.service.EmployeeServiceImpl;

public class MainUI {

	public static void main(String[] args) {

		boolean status = false;
		Scanner scanner = new Scanner(System.in);

		EmployeeService eService = new EmployeeServiceImpl();

		while (true) {

			System.out.println("1.Register \n2.Update \n3.Delete \n4.ViewAll \n5.Exit");
			int choice = scanner.nextInt();

			switch (choice) {
			case 1:

				try {

					System.out.println("enter name, designation, salary, phone");
					String name = scanner.next();
					String designation = scanner.next();
					double salary = scanner.nextDouble();
					long phone = scanner.nextLong();

					Employee employee = new Employee(name, designation, salary, phone);

					int empId = eService.saveEmployee(employee);

					if (empId > 0) {
						System.out.println("Customer registered successfully:" + empId);
					} else {
						System.out.println("not registered try again..");
					}

				} catch (Exception e) {
					e.printStackTrace();
				}

				break;

			case 2:
				
				
				
				break;

			case 3:
				break;

			case 4:
				break;

			case 5:
				System.out.println("Thank you!");
				System.exit(0);
				break;

			default:
				System.out.println("invalid choice!");
				break;
			}

		}

	}

}
