package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.bean.Employee;
import com.capgemini.service.DbConnection;

public class EmployeeDAOImpl implements EmployeeDAO {

	PreparedStatement statement = null;
	ResultSet resultSet = null;
	int row = -1;

	@Override
	public int insertEmployee(Employee employee) {

		int empId = 0;

		try (Connection connection = DbConnection.getConnection();) {

			statement = connection.prepareStatement("select empseq.NEXTVAL E from dual");
			resultSet = statement.executeQuery();

			if (resultSet.next())
				empId = resultSet.getInt(1);
			statement = connection.prepareStatement("insert into emp values(?,?,?,?,?)");
			statement.setInt(1, empId);
			statement.setString(2, employee.getFirstName());
			statement.setString(3, employee.getDesignation());
			statement.setDouble(4, employee.getSalary());
			statement.setLong(5, employee.getPhone());
			row = statement.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return empId;
	}

	@Override
	public int updateEmployee(Employee employee) {

		try (Connection connection = DbConnection.getConnection();) {

			statement = connection
					.prepareStatement("update emp set name=?,designation=?,salary=?,phone=?,where empId=?");

			statement.setString(1, employee.getFirstName());
			statement.setString(2, employee.getDesignation());
			statement.setDouble(3, employee.getSalary());
			statement.setLong(4, employee.getPhone());
			statement.setInt(5, employee.getEmployeeId());
			row = statement.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return row;
	}

	@Override
	public int deleteEmployee(int empId) {

		try (Connection connection = DbConnection.getConnection();) {

			statement = connection.prepareStatement("delete from emp where empId=?");

			statement.setInt(1, empId);
			row = statement.executeUpdate();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

		return row;
	}

	@Override
	public List<Employee> viewAll() {
		
		Employee employee = null;
		List<Employee> employeeList = new ArrayList<>();
		
		try (Connection connection = DbConnection.getConnection();) {

			statement = connection.prepareStatement("select * from emp");
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				employee = new Employee();
				employee.setEmployeeId(resultSet.getInt("empId"));
				employee.setFirstName(resultSet.getString("name"));
				employee.setDesignation(resultSet.getString("designation"));
				employee.setSalary(resultSet.getDouble("salary"));
				employee.setPhone(resultSet.getLong("phone"));
				employeeList.add(employee);

			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

		return employeeList;
	}

}
