package com.capgemini.dao;

import java.util.List;

import com.capgemini.bean.Employee;


public interface EmployeeDAO {
	
	int insertEmployee(Employee employee);
	int updateEmployee(Employee employee);
	int deleteEmployee(int empId);
	List<Employee> viewAll();

}
