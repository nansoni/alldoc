package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.Employee;

public interface EmployeeService {
	
	int saveEmployee(Employee employee);
	boolean updateEmployee(Employee employee);
	boolean removeEmployee(int empId);
	List<Employee> viewAll();

}
