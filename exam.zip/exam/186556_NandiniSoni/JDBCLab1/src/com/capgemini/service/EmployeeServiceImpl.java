package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.Employee;
import com.capgemini.dao.EmployeeDAO;
import com.capgemini.dao.EmployeeDAOImpl;

public class EmployeeServiceImpl implements EmployeeService {

	boolean status = false;
	int row = -1;
	EmployeeDAO eDao = new EmployeeDAOImpl();

	@Override
	public int saveEmployee(Employee employee) {

		row = eDao.insertEmployee(employee);
		if (row > 0)
			status = true;

		return row;
	}

	@Override
	public boolean updateEmployee(Employee employee) {

		row = eDao.updateEmployee(employee);
		if (row > 0)
			status = true;

		return status;
	}

	@Override
	public boolean removeEmployee(int empId) {

		row=eDao.deleteEmployee(empId);
		if(row>0)
			status=true;
		
		return status;
	}

	@Override
	public List<Employee> viewAll() {

		return eDao.viewAll();
	}

}
