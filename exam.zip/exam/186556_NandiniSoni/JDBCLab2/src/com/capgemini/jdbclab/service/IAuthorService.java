package com.capgemini.jdbclab.service;

import java.util.List;

import com.capgemini.jdbclab.bean.BookAuthor;

public interface IAuthorService {

	int saveAuthor(BookAuthor author);

	boolean updateAuthor(BookAuthor author);

	boolean removeCustomer(int authorId);

	BookAuthor viewById(int authorId);

	List<BookAuthor> viewAll();

}
