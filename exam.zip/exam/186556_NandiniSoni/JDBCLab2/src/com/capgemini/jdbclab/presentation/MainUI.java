package com.capgemini.jdbclab.presentation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.capgemini.jdbclab.bean.BookAuthor;
import com.capgemini.jdbclab.service.AuthorServiceImpl;
import com.capgemini.jdbclab.service.IAuthorService;



public class MainUI {
	
		public static void main(String[] args) {
			Scanner scanner = new Scanner(System.in);
			IAuthorService service = new AuthorServiceImpl();
			boolean staus= false;
			while(true) {
				System.out.println("1.Register\n2.update\n3.delete\n4.ViewbyId\n5ViewAll");
				int choice= scanner.nextInt();
				switch(choice) {
				case 0: System.exit(0);
				case 1:{
					System.out.println("Enter firstname,middleName,lastName,phone");
					String firstName = scanner.nextLine();
					String middleName = scanner.nextLine();
					String lastName=scanner.nextLine();
					long phone = scanner.nextLong();
					
					
				
					BookAuthor author = new BookAuthor(0,firstName,middleName,lastName,phone);
					int authorId = service.saveAuthor(author);
							if(authorId>0)
								
								System.out.println("Author register succesfully authorId"+authorId);
							else
								System.out.println("not registered try again...");
				}break;
				case 2:
					System.out.println("Enter authorId to update");
					int authorId = scanner.nextInt();
					System.out.println("Enter name,firstName,middleName,lastName,phone");
					String firstName = scanner.nextLine();
					String middleName = scanner.nextLine();
					String lastName = scanner.nextLine();
					long phone = scanner.nextLong();
					

					BookAuthor author = new BookAuthor(0,firstName,middleName,lastName,phone);
					boolean status = service.updateAuthor(author);
					if(status)
						System.out.println("Author updated succesfully");
					else
						System.out.println("Not updated try again");
					break;
				case 3:{
					System.out.println("Enter authorId to delete");
					authorId= scanner.nextInt();
					status = service.removeCustomer(authorId);
					if(status)
						System.out.println("Author deleted succesfully");
					else
						System.out.println("Not deleted try again");
					
					
				}break;
				case 4:{
					System.out.println("Enter authorId to view");
					 authorId =scanner.nextInt();
					 author= service.viewById(authorId);
					if(author!= null)
						System.out.println(author);
					else
						System.out.println("Author not found try again....");
				}break;
				case 5: {
					service.viewAll();
					}
				break;
				default:
					System.out.println("Enter valid input");
				}
				
			}
		}


}
