package com.capgemini.jdbclab.bean;

import java.util.Date;

public class BookAuthor {
	private int authorId;
	private String firstName ;
	private String middleName;
	private String lastName;
	private long phone;
	public BookAuthor() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BookAuthor(int authorId, String firstName, String middleName, String lastName, long phone) {
		super();
		this.authorId = authorId;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.phone = phone;
	}
	
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "BookAuthor [authorId=" + authorId + ", firstName=" + firstName + ", middleName=" + middleName
				+ ", lastName=" + lastName + ", phone=" + phone + "]";
	}
	

	
	

	
}
