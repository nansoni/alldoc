package com.capgemini.jdbclab.service;

import java.util.List;

import com.capgemini.jdbclab.bean.BookAuthor;
import com.capgemini.jdbclab.dao.AuthorDaoImpl;
import com.capgemini.jdbclab.dao.IAuthorDao;

public class AuthorServiceImpl implements IAuthorService {
	boolean status= false;
	int row = -1;
	IAuthorDao dao = new AuthorDaoImpl();
	@Override
	public int saveAuthor(BookAuthor author) {
		row = dao.insertAuthor(author);
		
		return row ;
		
	}

	@Override
	public boolean updateAuthor(BookAuthor author) {
		row = dao.updateAuthor(author);
		if(row>0)
			status = true;
		return status;
		
	}

	@Override
	public boolean removeCustomer(int authorId) {
		row = dao.deleteAuthor(authorId);
		if(row>0)
			status = true;
		return status;
		
	}

	@Override
	public BookAuthor viewById(int authorId) {
		
		return dao.getById(authorId);
	}

	@Override
	public List<BookAuthor> viewAll() {
		
		return dao.viewAll();
	}

}
