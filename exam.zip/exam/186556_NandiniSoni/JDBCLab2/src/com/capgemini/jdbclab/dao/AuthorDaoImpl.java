package com.capgemini.jdbclab.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.jdbc.connection.DBConnection;
import com.capgemini.jdbclab.bean.BookAuthor;

public class AuthorDaoImpl implements IAuthorDao {
	PreparedStatement statement = null;
	ResultSet resultSet = null;

	int row = -1;

	public void create() {
		try (Connection connection = DBConnection.getConnection();){
			
			String query = "create table BookAuthor(authorId number(5) primary key,firstName varchar2(25),middleName varchar2(25),lastName varchar2(25),phone number(10)";
			statement = connection.prepareStatement(query);
			boolean status = statement.execute();
			System.out.println("Table created " + status);// status is false, its true only if return statement is
															// result set
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	@Override
	public int insertAuthor(BookAuthor author) {
		int authorId = 0;
		try (Connection connection = DBConnection.getConnection();) {

			statement = connection.prepareStatement("select authorseq.NEXTVAL from dual");
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				authorId = resultSet.getInt(1);
				statement = connection.prepareStatement("insert into customer values(?,?,?,?,?)");
				statement.setInt(1, authorId);
				statement.setString(2, author.getFirstName());
				statement.setString(3, author.getMiddleName());
				statement.setString(4, author.getLastName());
				statement.setLong(5, author.getPhone());
				row = statement.executeUpdate();
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return authorId;

	}

	@Override
	public int updateAuthor(BookAuthor author) {
		try (Connection connection = DBConnection.getConnection();) {

			statement = connection
					.prepareStatement("update customer set firstName=?,middleName=?,lastName=?,phone=? where custId=?");

			statement.setString(1, author.getFirstName());
			statement.setString(2, author.getMiddleName());
			statement.setString(3, author.getLastName());
			statement.setLong(4, author.getPhone());
			statement.setInt(5, author.getAuthorId());

			row = statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;

	}

	@Override
	public int deleteAuthor(int authorId) {
		try (Connection connection = DBConnection.getConnection();) {

			statement = connection.prepareStatement("delete author from author where authorId=?");

			statement.setInt(1, authorId);

			row = statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}

	@Override
	public BookAuthor getById(int authorId) {
		BookAuthor author = null;
		try (Connection connection = DBConnection.getConnection();) {

			statement = connection.prepareStatement("select * from customer where custid = ?");

			statement.setInt(1, authorId);
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				author = new BookAuthor();
				author.setAuthorId(resultSet.getInt("authorId"));
				author.setFirstName(resultSet.getString("firstName"));
				author.setFirstName(resultSet.getString("middleName"));
				author.setFirstName(resultSet.getString("lastName"));
				author.setPhone(resultSet.getLong("phone"));
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return author;
	}

	@Override
	public List<BookAuthor> viewAll() {
		List<BookAuthor> authorlist = new ArrayList<>();
		BookAuthor author = null;

		try (Connection connection = DBConnection.getConnection();) {

			statement = connection.prepareStatement("select * from customer");
			while (resultSet.next()) {

				resultSet = statement.executeQuery();
				author = new BookAuthor();
				author.setAuthorId(resultSet.getInt("authorId"));
				author.setFirstName(resultSet.getString("firstName"));
				author.setMiddleName(resultSet.getString("middleName"));
				author.setLastName(resultSet.getString("lastName"));
				author.setPhone(resultSet.getLong("phone"));
				authorlist.add(author);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return authorlist;

	}

}
