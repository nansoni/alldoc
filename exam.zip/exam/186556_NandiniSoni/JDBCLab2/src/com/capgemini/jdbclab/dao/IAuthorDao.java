package com.capgemini.jdbclab.dao;

import java.util.List;

import com.capgemini.jdbclab.bean.BookAuthor;



public interface IAuthorDao {
	
		int insertAuthor(BookAuthor author);
		int updateAuthor(BookAuthor author);
		int deleteAuthor(int authorId);
		BookAuthor getById(int authorId);
		List<BookAuthor> viewAll();

		
		
	}


