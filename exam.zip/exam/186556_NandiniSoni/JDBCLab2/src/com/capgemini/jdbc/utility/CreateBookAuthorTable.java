package com.capgemini.jdbc.utility;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.jdbc.connection.DBConnection;



public class CreateBookAuthorTable {
	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet = null;
	boolean status = false;
	int row = -1;
	Scanner scanner = new Scanner(System.in);

	public void create() {
		try {
			connection = DBConnection.getConnection();
			String query = "create table BookAuthor(authorId number(5) primary key,firstName varchar2(25),middleName varchar2(25),lastName varchar2(25),phone number(10)";
			statement = connection.prepareStatement(query);
			status = statement.execute();
			System.out.println("Table created " + status);// status is false, its true only if return statement is
															// result set
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	
		
	
}


