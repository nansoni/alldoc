package com.cg.javaprogram.classAssignment;

import java.util.Scanner;

public class DivisibleBy3 {
	
	public int checkDivisiblity3(int number) {
		int remainder = 0; 
		int count = 0;
		while(number>0){
			
			remainder = number%10;
			
			if(remainder%3==0){
				count++;
			}
			number/=10;
		}
				
		return count;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner =  new Scanner(System.in);
		System.out.println("Enter number");
		int number = scanner.nextInt();
		
		DivisibleBy3 by3 = new DivisibleBy3();
		System.out.println(by3.checkDivisiblity3(number));
	}

}
