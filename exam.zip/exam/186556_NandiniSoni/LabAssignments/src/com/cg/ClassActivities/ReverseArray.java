package com.cg.javaprogram.classAssignment;

import java.util.Scanner;

public class ReverseArray {

	public static int[] reverseElement(int arr[]) {

		int output[] = new int[arr.length];
		for (int j = 0; j < arr.length; j++) {
			while (arr[j] > 0) {
				int remainder = arr[j] % 10;
				output[j] = (output[j] * 10) + remainder;
				arr[j] = arr[j] / 10;

			}
		}
		return output;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("size");
		int size = scanner.nextInt();
		int array[] = new int[size];
		for (int i = 0; i < array.length; i++) {
			array[i] = scanner.nextInt();
		}
	
		int output[] = reverseElement(array);
		for (int i = 0; i < output.length; i++) {
			System.out.println(output[i]);
			
		}
	}

}
