package com.cg.javaprogram.classAssignment;

import java.util.Scanner;

public class SubsequentIncrement {
	
	public int incrementNumber(int number) {
		int revNum= 0;
		while(number>0) { //321,32,3
			
			int remainder = number%10; //1,2,3
			revNum =  revNum*10 +(remainder+1); //2,23,234
			number = number/10;//32,3,0
		}
		int revNum1 = 0;
		while(revNum>0) {//234,23,2
			int remainder = revNum%10;//4,3,2
			revNum1 =  revNum1*10 +remainder;//4,43,432
			revNum = revNum/10;	//23,2,0
		}
		return revNum1;
		}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("number");
		int number = scanner.nextInt();
		SubsequentIncrement increment = new SubsequentIncrement();
		System.out.println(increment.incrementNumber(number));
	
	}

	

}
