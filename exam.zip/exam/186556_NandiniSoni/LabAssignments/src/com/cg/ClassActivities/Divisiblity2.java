package com.cg.javaprogram.classAssignment;

import java.util.Scanner;

public class Divisiblity2 {

		
		public int checkDivisiblity2(int number) {
			int remainder = 0; 
			int count = 0;
			while(number!=0) {
				
				remainder = number%10;
				if(remainder%2 == 0) {
					
					count++;
				}
				number/=10;
			}
			
			return count;

		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner =  new Scanner(System.in);
		System.out.println("Enter number");
		int number = scanner.nextInt();
		
		Divisiblity2 by2 = new Divisiblity2();
		System.out.println(by2.checkDivisiblity2(number));

	}

}
