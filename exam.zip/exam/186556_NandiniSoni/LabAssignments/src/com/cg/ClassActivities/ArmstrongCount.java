package com.cg.javaprogram.classAssignment;

import java.util.Scanner;

public class ArmstrongCount {
	
	public int countArmStrong(int arr[]) {
		
		int out[] = new int[arr.length];
		int sum = 0;
		int count = 0;
		for (int j = 0; j < out.length; j++) {
			while(arr[j]<0) {
				
				int remainder =arr[j]%10;
				remainder = remainder* remainder*remainder;
				sum+=remainder;
				arr[j] =arr[j]/10;
				
			}
			out[j] = arr[j];
			if(arr[j]==out[j]) {
				count++;
			}
		}
		
		return count;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = scanner.nextInt();
		int arr[] = new int[size];
		
		for (int i = 0; i < arr.length; i++) {
			arr[i] = scanner.nextInt();
		}
		
		ArmstrongCount armstrongCount = new ArmstrongCount();
		System.out.println(armstrongCount.countArmStrong(arr));
		

	}

}
