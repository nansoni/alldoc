package com.cg.java.lab11;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.cg.java.lab10.FileProgram;

class Ex1Runnable implements Runnable {
	public Ex1Runnable(String input) {
		FileInputStream fileInputStream = null;
		FileOutputStream fileOutputStream = null;

		try {

			fileInputStream = new FileInputStream(input);
			fileOutputStream = new FileOutputStream(
					"C:\\CoreJavaSpace\\CoreJava\\src\\com\\cg\\java\\lab10\\target.txt");

			int i = 0;
			while (i != -1) {
				i = fileInputStream.read();
				fileOutputStream.write(i);

				if (i % 10 == 0) {
					System.out.println("10 characters are copied");
					try {
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}

		} catch (FileNotFoundException e) {
			// TODO: handle exception
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	@Override
	public void run() {
		
	}
	
}

public class Exercise1 {
public static void main(String[] args) {
	ExecutorService executorService1 = Executors.newSingleThreadExecutor();
	Ex1Runnable myrunnable = new Ex1Runnable("C:\\CoreJavaSpace\\CoreJava\\src\\com\\cg\\java\\lab10\\source.txt");
	executorService1.execute(myrunnable);
}
}
