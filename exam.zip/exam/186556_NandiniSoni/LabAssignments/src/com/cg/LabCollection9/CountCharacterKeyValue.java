package com.cg.lab9;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class CountCharacterKeyValue {
	public Map countCharacter(char[] ch) {
		HashMap<Integer,Character> map = new HashMap<>();
		int count = 0;
		for(int i = 0;i<=ch.length-1;i++) {
			char store = ch[i];
			for(int j=0;j<ch.length;j++) {
				if(store == ch[j]) {
					count++;
					
				}
				
			}
			map.put(count,ch[i]);
			count =0;
			
			
			
		}
	
		return map;
		
	}
	public static void main(String[] args) throws IOException {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int size = scanner.nextInt();
		char[] ch = new char[size];
		System.out.println("enter the"+size+"character");
		for (int i = 0; i < ch.length; i++) {
		
			ch[i]= (char)System.in.read();
			
		}
		System.out.println(new CountCharacterKeyValue().countCharacter(ch));
		

	}

}
