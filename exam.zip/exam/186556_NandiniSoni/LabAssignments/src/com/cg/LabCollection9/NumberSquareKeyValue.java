package com.cg.lab9;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class NumberSquareKeyValue {
	public Map getSquares(int arr[]) {
		HashMap<Integer,Integer> map = new HashMap<>();
		//for (int i = 0; i < arr.length; i++) {
			//int store = arr[i]*arr[i];
			//map.put(i,store);
		//}
		List<Integer> list= new ArrayList<>();
		for (int i = 0; i < arr.length; i++) {
			list.add(i);
		}
		Iterator<Integer> it = list.iterator();
		while(it.hasNext()) {
			int store= it.next();
			map.put(store, store*store);
		}
		return map;
		
		
	}
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter size");
		int size = scanner.nextInt();
		int arr[] = new int[size];
		System.out.println("Enter the number");
		for (int i = 0; i < arr.length; i++) {
			arr[i]=scanner.nextInt();
			
		}
		System.out.println(new NumberSquareKeyValue().getSquares(arr));
		
	}

}
