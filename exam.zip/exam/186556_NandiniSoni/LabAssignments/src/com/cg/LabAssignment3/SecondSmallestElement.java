package com.cg.javaprogram.lab3;

import java.util.Arrays;
import java.util.Scanner;

public class SecondSmallestElement {

		
		public static int secondSmallest(int[] arr, int size) {
			Arrays.sort(arr);
			return(arr[1]);
		}
		public static void main(String[] args) {
			System.out.println("Enter elements");
			Scanner scanner= new Scanner(System.in);
			int size= scanner.nextInt();
			int arr[]= new int[size];
			for (int i = 0; i < size; i++) {
				arr[i]= scanner.nextInt();
			}
			System.out.println(secondSmallest(arr, size));
		}

}
