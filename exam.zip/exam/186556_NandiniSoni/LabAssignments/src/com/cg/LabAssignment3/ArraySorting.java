package com.cg.javaprogram.lab3;

import java.util.Arrays;
import java.util.Scanner;

public class ArraySorting {
	public static String[] sortarr(String[] arr, int size) {
		Arrays.sort(arr);
		for (int i = 0; i < (size/2); i++) {
			arr[i]= arr[i].toUpperCase();
		}
		for (int i = (size/2)+1; i <size ; i++) {
			arr[i]= arr[i].toLowerCase();
		}
		return arr;
	}
	public static void main(String[] args) {
		Scanner scanner= new Scanner(System.in);
		int size= scanner.nextInt();
		scanner.nextLine();
		String arr[]= new String[size];
		for (int i = 0; i < size; i++) {
			arr[i]= scanner.nextLine();
		}
		String arr1[]= new String[size];
		arr1= sortarr(arr, size);
		for (int i = 0; i < size; i++) {
			System.out.println(arr1[i]);
		}
	}

}
