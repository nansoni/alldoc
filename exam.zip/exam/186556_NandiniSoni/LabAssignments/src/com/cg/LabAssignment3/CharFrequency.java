package com.cg.javaprogram.lab3;

import java.util.Scanner;

public class CharFrequency {
	public static int charFreq(char[] array, char a) {
		int c=0;
		for (int i = 0; i < array.length; i++) {
			if(array[i]==a) {
				++c;
			}
		}
		return c;
	}
	public static void main(String[] args) {
		System.out.println("Enter the size");
		Scanner scanner= new Scanner(System.in);
		int size= scanner.nextInt();
		System.out.println("Enter the string");
		char[] array= scanner.next().toCharArray();
		char a= scanner.next().charAt(0);
		System.out.println(charFreq(array, a));
		scanner.close();
	}

}
