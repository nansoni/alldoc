package com.cg.lab4;

import java.util.Scanner;

public class SumCubesOfNumber {
	public int cubes(int n) {
		int sum = 0;
		while (n > 0) {
			int rem = n % 10;
			sum = sum + (rem * rem * rem);
			n = n / 10;

		}
		return sum;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter num");
		int res1 = scanner.nextInt();
		SumCubesOfNumber o = new SumCubesOfNumber();
		int count = o.cubes(res1);
		System.out.println("cube is" + count);
	}
}
