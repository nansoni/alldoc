/*Write a program to do the following operations using Thread:
Create an user defined Thread class called as �CopyDataThread .java� .
This class will be designed to copy the content from one file �source.txt � to another file 
�target.txt� and 
after every 10 characters copied, �10 characters are copied� message will
be shown to user.(Keep delay of 5 seconds after every 10 characters read.) Create another
class �FileProgram.java� which will create above thread.
Pass required File Stream classes to CopyDataThread constructor and implement the above functionality.
*/

package com.cg.lab10;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyDataThread {

	public void copyThread() {
		FileInputStream fin = null;
		FileOutputStream fout = null;

		try {

			fin = new FileInputStream("/LabAssignments/src/com/cg/lab10/sorce.txt");
			fout = new FileOutputStream("/LabAssignments/src/com/cg/lab10/target.txt");
			int i = 0;
			while (i != -1) {
				i = fin.read();
				fout.write(i);
				System.out.print((char) i);

			}

		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
