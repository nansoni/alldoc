//Write a thread program to display
//timer where timer will get refresh after every 10seconds.( Use Runnable implementation )

package com.cg.lab10;
import java.util.Calendar;
public class DateThread extends Thread {
private class RunnableImpl implements Runnable {

		public void run() {
			for (int i = 1; i <= 80; i++) {
				Calendar c = Calendar.getInstance();
				try {
System.out.println(c.get(Calendar.HOUR_OF_DAY)+"Hour :"+ +c.get(Calendar.MINUTE)+"Minute : " 
							+ c.get(Calendar.SECOND)+ "Second : " +c.get(Calendar.AM_PM));
					Thread.sleep(10000);
				} catch (InterruptedException e) {
					e.getMessage();
				}

			}
		}
	}

	public static void main(String[] args) {

		Thread t1 = new Thread(new DateThread().new RunnableImpl());
		t1.start();
	}
}