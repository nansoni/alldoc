package com.cg.javaprogram.lab5;


import java.util.InputMismatchException;
import java.util.Scanner;

public class CheckAge {

	public void checkAge() throws InvalidAgeException {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter age:");
		int age = 0;
		age = scanner.nextInt();
		try {
			
			if(age<15) {
				throw new InvalidAgeException("age should be greater than 15");			}
			
		} catch (InputMismatchException e) {
			System.out.println(e.getMessage());
			
		}

	
	}

	public static void main(String[] args) {

		CheckAge age2 = new CheckAge();
		try {
			age2.checkAge();
		} catch (InvalidAgeException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
	}

}