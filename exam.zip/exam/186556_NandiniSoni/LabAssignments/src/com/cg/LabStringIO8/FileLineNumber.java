//Exercise 2: Write a Java program that reads a file and displays the file
//on the screen, with a line number before each line?

package com.cg.lab8;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileLineNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileInputStream fin = null;
		FileOutputStream fout = null;
	
		int line = 0;
		try {
			fin = new FileInputStream("C:\\core_java\\IODemo\\src\\main\\java\\com\\cg\\IODemo\\FileDemo.java");
			int i = 0,lineNo=1;
			System.out.println(lineNo+".\t");
			
			while(i!= -1) {
				i = fin.read();
				char a = (char)i;
				System.out.print(a);
				if(a =='\n') {
					lineNo++;
					System.out.println(lineNo+"\t");
				}
			}
		}catch(Exception e) {
			e.getMessage();
		}
	}			
		
	}
