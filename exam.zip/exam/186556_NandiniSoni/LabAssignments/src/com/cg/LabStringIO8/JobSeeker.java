//7: You are asked to create an application for registering the details of jobseeker. The requirement is:
//Username should always end with _job and there should be at least minimum of 8 characters to the left of _job. Write a function to validate the same.
//Return true in case the validation is passed. In case of validation failure return false.

package com.cg.lab8;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class JobSeeker {
	public static boolean isValid(String str) {
	boolean flag = false;
		Pattern ptn=Pattern.compile("^[A-Z]{1}[a-z]{7,}_job$");
		Matcher match= ptn.matcher(str);
		if(match.matches()) {
			flag= true;
		}
		return flag;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter your name");
		String str= scanner.next();
		if(!isValid(str)) {
			try {
				throw new Exception("Enter name with 8 character +_job");
			}catch(Exception e) {
				e.getMessage();
			}
		}else {
			System.out.println("Passed");
		}
	}

}

