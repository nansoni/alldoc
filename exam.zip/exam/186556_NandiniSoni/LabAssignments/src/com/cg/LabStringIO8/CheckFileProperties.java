//Write a Java program that reads on file name from the user,
//then displays information about whether the file exists, whether the file is readable, whether the file is writable, the type of file and the length of the file in bytes?

package com.cg.lab8;

import java.io.File;
import java.util.Scanner;

public class CheckFileProperties {
	public static void main(String[] args) {
		System.out.println("Enter file location");
		Scanner scanner= new Scanner(System.in);
		String input= scanner.next();
		File f1= new File(input);
		
		System.out.println("File Name:"+f1.getName());
		System.out.println("This file is:"+f1.exists());
		System.out.println("Is Readable:"+f1.canRead());
		System.out.println("Is Writable:"+f1.canWrite());
		System.out.println("Is file"+f1.isFile());
		System.out.println("Is Directory:"+f1.isDirectory());
		System.out.println("Is Hidden:"+f1.isHidden());
		System.out.println("File Size:"+f1.length() +"bytes");
		scanner.close();
		
	}

}
