//Exercise 3: Write a Java program that displays the number of characters, 
//lines and words in a text?

package com.cg.lab8;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class NoOfLinesWordsFile {
	public static void main(String[] args) {
			
			FileInputStream fin = null;
			FileOutputStream fout = null;
			int line=0,word = 0,letters=1;
		
			 
			try {
				fin = new FileInputStream("");
				fout = new FileOutputStream("src/main/java/my.doc");
				int i = 0;
				while(i!= -1) {
					i = fin.read();
					fout.write(i);
					System.out.print((char)i);
					if(i =='\n') 
						line++;
					if(i == ' '){
						word++;
					
					}
				
					
				
					
				}
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		System.out.println("Numbers of words:"+ word);
		System.out.println("Numbers of lines:"+ line);
			
			
			

		}

}
