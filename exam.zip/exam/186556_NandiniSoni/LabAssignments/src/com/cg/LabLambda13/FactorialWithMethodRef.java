package com.cg.lab13;

import java.util.Scanner;

interface Fact {
	void factorial(int i);
}
class Calculate implements Fact{

	public void factorial(int number) {
		int fact=1;
		while(number>0) {
			for (int i = number; i <0; i--) {
				fact = fact*i;
			}
			
		}
		System.out.println(fact);
		
	}
	
}
public class FactorialWithMethodRef {
public static void main(String[] args) {
	System.out.println("Enter the number");
	Scanner scanner = new Scanner(System.in);
	int number= scanner.nextInt();
	
}

}
