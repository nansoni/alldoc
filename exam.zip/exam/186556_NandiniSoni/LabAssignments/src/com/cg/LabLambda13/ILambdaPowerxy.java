package com.cg.lab13;

public interface ILambdaPowerxy {
	int power1(int x,int y);

}
