package com.cg.javaproject.lab1;

import java.util.Scanner;

public class Sum {
	
	int calculateSum() {
		
		int sum = 0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter number");
		int number = scanner.nextInt();
		for(int i =0;i<=number;i++) {
			if(i%3== 0 && i%5==0) {
	
				sum = sum +i;
			}
		}
		return sum;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Sum sum= new Sum();
		System.out.println(sum.calculateSum());
	
	

	}

}

