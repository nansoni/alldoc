
package com.cg.javaproject.lab1;

import java.util.Scanner;

public class Difference {
	
	int calculateDifferences() {
		 
		int difference = 0 ;
		int sumOfSquareOfNumbers = 0;
		int sumOfNumbers=0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a number");
		int number = scanner.nextInt();
		for(int i =0;i<=number;i++) {
		 sumOfSquareOfNumbers += i*i;
		 sumOfNumbers += i;
			
		}
		difference = sumOfSquareOfNumbers - (sumOfNumbers*sumOfNumbers);
		return difference;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Difference difference = new Difference();
		System.out.println(difference.calculateDifferences());
		
	}

}
