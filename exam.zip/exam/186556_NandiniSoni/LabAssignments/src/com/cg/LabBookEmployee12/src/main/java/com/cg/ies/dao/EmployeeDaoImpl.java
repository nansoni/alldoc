
package com.cg.ies.dao;

import java.util.HashMap;

import com.cg.ies.bean.Employee;

public class EmployeeDaoImpl implements EmployeeDAO {
	HashMap<Integer,Employee> employees=new HashMap<Integer,Employee>();

	@Override
	public int addEmployeeDetails(Employee employee) {
		employees.put(employee.getEmployeeId(), employee);
		return employee.getEmployeeId();
	}

	@Override
	public HashMap<Integer, Employee> getAllDetails() {
		
		return employees;
	}

}
