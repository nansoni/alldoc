package com.cg.ies.service;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ies.bean.Employee;
import com.cg.ies.dao.EmployeeDAO;
import com.cg.ies.dao.EmployeeDaoImpl;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeDAO empDao=new EmployeeDaoImpl();

	@Override
	public int addEmployeeDetails(Employee employee) {
		int employeeId=(int)(Math.random()*1000);
		employee.setEmployeeId(employeeId);
		return empDao.addEmployeeDetails(employee);
	}

	@Override
	public HashMap<Integer, Employee> getAllDetails() {
		
		return empDao.getAllDetails();
	}
	public boolean isNameValid(String name) {
		Pattern nameptn=Pattern.compile("^[A-Z]{1}[a-z]{4,}$");
		Matcher match=nameptn.matcher(name);
		if(match.matches()) {
			return true;
		}
		return false;

}
}
