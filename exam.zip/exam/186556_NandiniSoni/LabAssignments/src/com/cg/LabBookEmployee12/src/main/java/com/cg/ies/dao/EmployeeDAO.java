package com.cg.ies.dao;

import java.util.HashMap;

import com.cg.ies.bean.Employee;

public interface EmployeeDAO {
	public int addEmployeeDetails(Employee employee);
	public HashMap<Integer,Employee> getAllDetails();

}
