package com.cg.ies.pl;

import java.util.Scanner;

import com.cg.ies.bean.Employee;
import com.cg.ies.exception.EmployeeException;
import com.cg.ies.service.EmployeeServiceImpl;

public class EmployeeUI {
	
	static EmployeeServiceImpl service =new EmployeeServiceImpl();
	static Scanner scanner=new Scanner(System.in);
	static void addEmployeeDetails() {
		System.out.println("enter employee id:");
		int id=scanner.nextInt();
		scanner.nextLine();
		 System.out.println("Enter employee Name");
		String name=scanner.nextLine();
		System.out.println("enter employee salary");
		double salary=scanner.nextDouble();
		String designation=null,insuranceScheme=null;
		if(salary>=40000) {
	     designation="Manager";
		 insuranceScheme= "Scheme A";
		}
		
		else if(salary>=20000&&salary<40000) {
			 designation="Programmer";
			 insuranceScheme= "Scheme B";
		}
		else if(salary>5000&&salary<20000) {
			 designation="System Associate";
			insuranceScheme= "Scheme C";
		}
		else if(salary<= 5000) {
			 designation="Clerk";
		     insuranceScheme= " No Scheme";
		}
		if(!service.isNameValid(name))
			try {
				throw new EmployeeException("Name is invalid");
			} catch (EmployeeException e) {
				
				System.err.println(e.getMessage());
			}
		else
		{
			Employee employee=new Employee(id, name, salary, designation, insuranceScheme);
			int employeeId=service.addEmployeeDetails(employee);
			System.out.println("employee is registered successfully and id is");
			
			
		}
	}

	
	
	public static void main(String[] args) {
		
		String option=null;
		do {
			System.out.println("1.Add Employee details\n2.ViewAll\n0.Exit");
			int choice=scanner.nextInt();
			switch(choice) {
			case 0: System.exit(0);
			case 1:addEmployeeDetails();
			break;
			case 2:System.out.println(service.getAllDetails());
			break;
	}
			System.out.println("press y to continue");
			option=scanner.next();
			}
			while(option.equalsIgnoreCase("y"));
			
			scanner.close();


			}}
		
			


	
