package com.cg.ies.tset;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.ies.bean.Employee;
import com.cg.ies.dao.EmployeeDAO;
import com.cg.ies.dao.EmployeeDaoImpl;

class EmployeeDaoImplTest {
	static EmployeeDAO dao;
	Employee emp;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		dao=new EmployeeDaoImpl();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		dao=null;
	}

	@BeforeEach
	void setUp() throws Exception {
		emp=new Employee(369, "Ashritha", 25000, "Programmer", "Scheme B");
	}

	@AfterEach
	void tearDown() throws Exception {
		emp=null;
	}

	@Test
	void testEmployeeDetails() {
		assertEquals(369, dao.addEmployeeDetails(emp));
	}

}
