package com.cg.ies.service;

import java.util.HashMap;

import com.cg.ies.bean.Employee;

public interface EmployeeService {
	public int addEmployeeDetails(Employee employee);
	public HashMap<Integer,Employee> getAllDetails();

}
