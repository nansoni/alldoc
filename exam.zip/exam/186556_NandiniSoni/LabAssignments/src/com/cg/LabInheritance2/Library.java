package com.cg.javaprogram.lab2;

import java.util.Scanner;

public class Library extends  Item{

	public static void main(String[] args) {
		
		System.out.println("Inside Library");
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Member id");
		int id=scanner.nextInt();
		
		System.out.println("Enter year of book published");
		int year=scanner.nextInt();
		

		System.out.println("Enter Author");
		String author=scanner.next();
		
		System.out.println("Enter Genre");
		String genre=scanner.next();
		
		System.out.println("Enter Director");
		String director=scanner.next();

		System.out.println("Enter Arist name");
		String artist=scanner.next();
		
		
		Item obj=new Library();
		obj.checkIn(id);
		obj.checkIn(id);
		
		Video obj1=new Video(director,genre,year);
		obj1.printDetails();
		
		CD obj2=new CD(artist,genre);
		obj2.printDetails();
		
		JournalPaper obj3=new JournalPaper(author);
		obj3.printyear(year);
		
		obj3.checkIn(id);
		obj3.checkOut(id);
		
		
		
	}

	@Override
	public void checkIn(int id) {
		System.out.println("The member with id "+id+ "check in");
		
	}

	@Override
	public void checkOut(int id) {
		System.out.println("The member with id "+id+ "check out..$#^");
		
	}

}
