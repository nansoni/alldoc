import { Component, OnInit } from '@angular/core';
import { IMobile } from '../imobile';
import { MobileService } from './mobile.service';
import { Router } from '@angular/router';
/**
 * @author nansoni
 * date-10Aug2019
 */
@Component({
  selector: 'app-addmobile',
  templateUrl: './addmobile.component.html',
  styleUrls: ['./addmobile.component.css']
})
/**
 * defining inside constructor mobile service and router as private so that it can be accessed.
 */
export class AddmobileComponent implements OnInit {
/**
 * 
 * @param mobileService 
 * @param router 
 */
  constructor(private mobileService:MobileService, private router:Router) { }
  
  ngOnInit() {
  }
  /**
   * 
   * @param mobile 
   */
  addMobile(mobile:IMobile){
    //console.log(mobile);
    this.mobileService.addMobiles(mobile)
    this.router.navigate(['/show'])
  }
  
  
}
