import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IMobile } from '../imobile';
@Injectable({
  providedIn: 'root'
})

export class MobileService {
  mobiles:IMobile[]=[];
/**
 * 
 * @param http 
 */
  constructor(private http:HttpClient) {
}
/**
 * method to get data
 */
getData(){
  return this.mobiles;
}
addMobiles(mobile:IMobile){
  this.mobiles.push(mobile);
  /**
   * method for adding mobiles
   */
}
setMobiles(mobiles:IMobile[]){
  this.mobiles=mobiles;
  /**
   * method to set mobiles
   */
}
deleteMobiles(id:number){
  this.mobiles.splice(id,1);
  this.mobiles=this.mobiles.filter(s=>s.id!=id)
  /**
   * method to delete mobile
   */
}
}
