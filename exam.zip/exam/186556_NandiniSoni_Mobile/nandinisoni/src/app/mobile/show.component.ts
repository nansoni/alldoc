import { Component, OnInit } from '@angular/core';
import { IMobile } from '../imobile';
import { MobileService } from './mobile.service';
import { Router } from '@angular/router';
/**
 *  @author nansoni
 * date-10Aug2019
 */
@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
  mobiles: IMobile[];
/**
 * 
 * @param mobileService 
 * @param router 
 */
  constructor(private mobileService: MobileService, private router: Router) { }
/**
 * constructor declaration, defining service and router as private
 */
  ngOnInit() {
      this.mobiles = this.mobileService.getData();
    /**
     * calling through service to get data
     */

  }
  deleteMobile(i: number) {
    if (confirm("Are you sure you want to delete??")) {
      this.mobileService.deleteMobiles(i);
      console.log("Deleted" + i + "Object");
      /**
       * asking the user if he wants to delete the value if user confirms as okay then only value gets deleted.
       */
    }

  }
}
