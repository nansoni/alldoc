import { IMobile } from './imobile';

describe('IMobile', () => {
  it('should create an instance', () => {
    expect(new IMobile()).toBeTruthy();
  });
});
