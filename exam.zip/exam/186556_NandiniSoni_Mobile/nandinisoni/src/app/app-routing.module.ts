import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowComponent } from './mobile/show.component';
import { AddmobileComponent } from './mobile/addmobile.component';

/**
 * importing all the required components
 */
const routes: Routes = [
  /**
   * routing from one path to the another 
   */
  {path:"show",component:ShowComponent}, 
  {path:"add",component:AddmobileComponent},
  {path:'',component:ShowComponent}
  /**
   * routing for show
   * routing for add
   */
];

@NgModule({
  /**
   * 
   */
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
