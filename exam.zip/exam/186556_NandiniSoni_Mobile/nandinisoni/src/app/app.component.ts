import { Component } from '@angular/core';
/**
 *  @author nansoni
 * date-10Aug2019
 */
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'nandinisoni';
}
