export interface IMobile{
    id:number;
    name:string;
    price:number;
    brand:string;
  /**
   * interface of mobiles
   * defining
   * id type as number
   * name type as string
   * price type as number
   * brand type as string
   */
}