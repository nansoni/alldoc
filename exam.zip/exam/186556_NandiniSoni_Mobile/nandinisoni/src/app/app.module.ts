import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { ShowComponent } from './mobile/show.component';
import { AddmobileComponent } from './mobile/addmobile.component';
import { MobileService } from './mobile/mobile.service';
/**
 * imported FormsModule and
    HttpClientModule for get set methods used in the project
 */
@NgModule({
  declarations: [
    AppComponent,
    ShowComponent,
    AddmobileComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule 
/**
 * imported FormsModule and
    HttpClientModule for get set methods used in the project
 */
  ],
  providers: [MobileService],
  /**
   * service class here in providers
   */
  bootstrap: [AppComponent]
})
export class AppModule { }
