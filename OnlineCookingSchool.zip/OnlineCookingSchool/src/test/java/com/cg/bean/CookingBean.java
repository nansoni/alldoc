package com.cg.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CookingBean {

	WebDriver driver;

	@FindBy(how = How.NAME, using = "fname")
	@CacheLookup
	WebElement firstname;

	@FindBy(how = How.NAME, using = "lname")
	@CacheLookup
	WebElement lastname;

	@FindBy(how = How.NAME, using = "email")
	@CacheLookup
	WebElement email;

	@FindBy(how = How.NAME, using = "mobile")
	@CacheLookup
	WebElement mobile;

	@FindBy(how = How.NAME, using = "D6")
	@CacheLookup
	WebElement category;

	@FindBy(how = How.NAME, using = "D5")
	@CacheLookup
	WebElement city;

	@FindBy(how = How.NAME, using = "D4")
	@CacheLookup
	WebElement learning;

	
	@FindBy(how = How.NAME, using = "D1")
	@CacheLookup
	WebElement courceDuration;

	@FindBy(how = How.NAME, using = "enqdetails")
	@CacheLookup
	WebElement enquiry;

	@FindBy(how = How.ID, using = "Submit1")
	@CacheLookup
	WebElement submitButton;

	public CookingBean(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname.sendKeys(firstname);

	}

	public WebElement getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname.sendKeys(lastname);

	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);

	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);

	}

	public WebElement getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category.sendKeys(category);

	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);

	}

	public WebElement getLearning() {
		return learning;
	}

	public void setLearning(String learning) {
		this.learning.sendKeys(learning);

	}

	public WebElement getCourceDuration() {
		return courceDuration;
	}

	public void setCourceDuration(String courceDuration) {
		this.courceDuration.sendKeys(courceDuration);

	}

	public WebElement getEnquiry() {
		return enquiry;
	}

	public void setEnquiry(String enquiry) {
		this.enquiry.sendKeys(enquiry);

	}

	public WebElement getSubmitButton() {
		return submitButton;
	}

	public void setSubmitButton() {
		this.submitButton.click();
	}

}
