package com.cg.cookingstepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.bean.CookingBean;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;


public class CookingStepDef {

	private WebDriver driver;
	private CookingBean bean;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:/Users/nansoni/Desktop/chromedriver.exe");
		driver = new ChromeDriver();
	}

	@Given("^user is on Online Cooking School$")
	public void user_is_on_Online_Cooking_School() throws Throwable {
		driver.get("C:\\Users\\nansoni\\Desktop\\Module 4 test scripts\\SET08\\Recipe_class_registration.html");
		bean = new CookingBean(driver);
	}

	@Then("^check if title of the page is 'Online Cooking School-Taste of Home'$")
	public void check_if_title_of_the_page_is_Online_Cooking_School_Taste_of_Home() throws Throwable {
		String expectedMessage = "Online Cooking Class Enquiry Form";
		String actualMessage = driver.getTitle();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();

	}

	@Given("^user is on 'Enquiry Form' page$")
	public void user_is_on_Enquiry_Form_page() throws Throwable {
		driver.get("C:\\Users\\nansoni\\Desktop\\Module 4 test scripts\\SET08\\Recipe_class_registration.html");
		bean = new CookingBean(driver);
	}

	@When("^user clicks on 'Download our Recipe class Brochure' button$")
	public void user_clicks_on_Download_our_Recipe_class_Brochure_button() throws Throwable {
		driver.findElement(By.linkText("Download our Recipe class Brochure")).click();
		

	}

	@Then("^verify the text 'Recipe class Brochure is sent to your registered mail id' on page$")
	public void verify_the_text_Recipe_class_Brochure_is_sent_to_your_registered_mail_id_on_page() throws Throwable {
		String bodyText = driver.findElement(By.tagName("body")).getText();
		Assert.assertTrue("Text not found!",
				bodyText.contains("Recipe class Brochure is sent to your registered mail id"));

	}

	@Given("^user is on 'message' page$")
	public void user_is_on_message_page() throws Throwable {
		driver.get("C:\\Users\\nansoni\\Downloads\\185916_SET8\\msg.html");

	}

	@When("^user clicks on 'Go Back to Registration' button$")
	public void user_clicks_on_Go_Back_to_Registration_button() throws Throwable {
		driver.findElement(By.linkText("Go Back to Registration")).click();

	}

	@Then("^displays 'enquiry form' page$")
	public void displays_enquiry_form_page() throws Throwable {
		String expectedMessage = "Online Cooking Class Enquiry Form";
		String actualMessage = driver.getTitle();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();

	}

	@Given("^user is on 'Enquire Form' page$")
	public void user_is_on_Enquire_Form_page() throws Throwable {
		driver.get("C:\\Users\\nansoni\\Desktop\\Module 4 test scripts\\SET08\\Recipe_class_registration.html");
		bean = new CookingBean(driver);
	}

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
		bean.setFirstname("");
		bean.setSubmitButton();

	}

	@Then("^display 'First name must be filled out'$")
	public void display_First_name_must_be_filled_out() throws Throwable {
		String expectedMessage = "First Name must be filled out";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();

	}

	@When("^user enters invalid last name$")
	public void user_enters_invalid_last_name() throws Throwable {
		bean.setFirstname("sai");
		bean.setLastname("");
		bean.setSubmitButton();

	}

	@Then("^display 'Last name must be filled out'$")
	public void display_Last_name_must_be_filled_out() throws Throwable {
		String expectedMessage = "Last Name must be filled out";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();

	}

	@When("^user enters invalid mobile$")
	public void user_enters_invalid_mobile() throws Throwable {
		bean.setFirstname("sai");
		bean.setLastname("Venkat");
		bean.setMobile("hghds");
		bean.setSubmitButton();
	}

	@Then("^display 'Enter numeric value'$")
	public void display_Enter_numeric_value() throws Throwable {
		String expectedMessage = "Enter numeric value";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();

	}

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number() throws Throwable {
		bean.setFirstname("sai");
		bean.setLastname("Venkat");
		bean.setMobile("65546");
		bean.setSubmitButton();

	}

	@Then("^display 'Enter (\\d+) digit Mobile number'$")
	public void display_Enter_digit_Mobile_number(int arg1) throws Throwable {
		String expectedMessage = "Enter 10 digit Mobile number";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();

	}

	@When("^user clicks on 'Enquire Now!!!' button$")
	public void user_clicks_on_Enquire_Now_button() throws Throwable {
		bean.setFirstname("nandini");
		bean.setLastname("soni");
		bean.setEmail("nandini@gmail.com");
		bean.setMobile("9767676767");
		bean.setCategory("Non-Veg");
		bean.setCity("mumbai");
		bean.setLearning("In house training");
		bean.setCourceDuration("audi");
		bean.setEnquiry("dfgfdg");
		bean.setSubmitButton();

	}

	@Then("^display 'Thank you for submitting the online recipe class Enquiry'$")
	public void display_Thank_you_for_submitting_the_online_recipe_class_Enquiry() throws Throwable {
		String expectedMessage = "Thank you for submitting the online recipe class Enquiry";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^user clicks on 'Alert Box' message$")
	public void user_clicks_on_Alert_Box_message() throws Throwable {
		driver.switchTo().alert().accept();
	}

	@Then("^display 'Our location representative will contact you soon'$")
	public void display_Our_location_representative_will_contact_you_soon() throws Throwable {
		String bodyText = driver.findElement(By.tagName("body")).getText();
		Assert.assertTrue("Text not found!", bodyText.contains("Our location representative will contact you soon."));

	}

}
