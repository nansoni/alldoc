package com.cg.cookingstepdef;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty" },features = {"C:\\BDD556\\OnlineCookingSchool\\src\\test\\java\\com\\cg\\cookingfeature\\CookingFeature.feature"})
public class CookingRunner {

}
