package com.userservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.userbean.User;
import com.userdao.UserDao;
import com.userexception.UserException;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDao UserDAO;

	@Autowired
	@Override
	public List<User> createUser(User user) throws UserException {
		UserDAO.save(user);
		return getAllUser();
	}

	@Override
	public List<User> getAllUser() throws UserException {
		return UserDAO.findAll();
	}

	@Override
	public User getUserById(int id) throws UserException {
		return UserDAO.findById(id).get();
	}

	@Override
	public List<User> editUser(User user, int id) throws UserException {
		if(UserDAO.existsById(id)) {
		UserDAO.save(user);
		}
		return getAllUser();
	}

	@Override
	public List<User> deleteUser(int id) throws UserException {
		UserDAO.deleteById(id);
		return getAllUser();
	}

}
