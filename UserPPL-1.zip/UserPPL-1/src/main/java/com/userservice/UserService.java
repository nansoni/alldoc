package com.userservice;

import java.util.List;

import com.userbean.User;
import com.userexception.UserException;


public interface UserService {

	List<User> createUser(User user) throws UserException ;
	List<User> deleteUser(int id) throws UserException ;
	List<User> editUser(User user,int id) throws UserException ;
	List<User> getAllUser() throws UserException ;
	User getUserById(int id) throws UserException;
	
}
