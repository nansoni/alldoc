package com.usercontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.userbean.User;
import com.userexception.UserException;
import com.userservice.UserService;



@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class UserController {

	@Autowired
	private UserService service;

	@PostMapping
	public List<User> createUser(@RequestBody User user) throws UserException {
		return service.createUser(user);
	}

	@GetMapping
	public List<User> getAllUser() throws UserException {
		return service.getAllUser();
	}

	@DeleteMapping("{id}")
	public List<User> deleteUser(@PathVariable int id) throws UserException {
		return service.deleteUser(id);
	}

	@GetMapping("{id}")
	public User getUserById(@PathVariable int id) throws UserException {
		return service.getUserById(id);
	}
	
	@PutMapping("{id}")
	public List<User> editUser(@PathVariable User user,@RequestBody int id) throws UserException {
		return service.editUser(user, id);
	}

}
