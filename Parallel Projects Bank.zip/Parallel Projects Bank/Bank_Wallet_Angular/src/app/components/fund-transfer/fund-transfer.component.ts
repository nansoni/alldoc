import { Component, OnInit } from '@angular/core';
import { Transaction } from '../../models/Transaction.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { WalletService } from 'src/app/services/wallet.service';
import { SampleResponse } from 'src/app/models/SampleResponse.model';
@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {
  transferForm: FormGroup;
  response: SampleResponse;
  constructor(private service: WalletService, private formBuilder: FormBuilder) {
  }
  ngOnInit() {
    this.transferForm = this.formBuilder.group({
      accountNum: ['', [Validators.required, Validators.pattern("^[A-Z]{3}\\d{10}$")]],
      recAccountNum: ['', [Validators.required, Validators.pattern("^[A-Z]{3}\\d{10}$")]],
      amount: ['', [Validators.required, Validators.pattern("^[1-9][0-9]*$")]],
      password: ['', Validators.required]
    });
  }
  get formControls() { return this.transferForm.controls; }
  onSubmit() {
    if (this.transferForm.invalid) {
      return;
    }
    let accountNum: string = this.formControls.accountNum.value;
    let recAccountNum: string = this.formControls.recAccountNum.value;
    let amount: number = parseFloat(this.formControls.amount.value);
    let password: string = this.formControls.password.value;
    this.transfer(amount, accountNum, password, recAccountNum);
  }
  transfer(amount: number, accountNum: string, password: string, recAccountNum: string) {
    this.service.transfer(amount, accountNum, password, recAccountNum).then(response => { this.response = response;
    alert("Fund Transfer Successful. Remaining Balance : "+ this.response.result['balance'] +" Rs.")}
      , err => {
        if (err.success != undefined && err.success == false) {
          this.response = err;
        }
      });
  }

}
