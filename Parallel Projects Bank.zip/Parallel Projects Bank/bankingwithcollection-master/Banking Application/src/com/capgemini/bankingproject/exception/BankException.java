package com.capgemini.bankingproject.exception;

public class BankException extends Exception{

	public BankException(String message) {
		super(message);
		
	}
	

}
